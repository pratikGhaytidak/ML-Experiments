import socket
import threading

HOST = "127.0.0.1"
PORT = 5001
ready = threading.Event()


def server():
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.bind((HOST, PORT))
        print("UDP server waiting...")
        ready.set()
        message, addr = s.recvfrom(1024)
        print("Client says:", message.decode())
        s.sendto(b"Hello from server", addr)


def client():
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as c:
        c.settimeout(5)
        c.sendto(b"Hello from client", (HOST, PORT))
        try:
            reply, _ = c.recvfrom(1024)
            print("Server says:", reply.decode())
        except socket.timeout:
            print("No reply from server")


listener = threading.Thread(target=server)
listener.start()
ready.wait()
client()
listener.join()

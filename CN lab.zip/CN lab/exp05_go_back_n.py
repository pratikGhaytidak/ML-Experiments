def read_int(prompt, minimum=1):
    value = int(input(prompt))
    if value < minimum:
        raise ValueError
    return value


try:
    total = read_int("Enter total number of frames: ")
    window = read_int("Enter window size: ")
    lost = read_int("Enter frame number to lose once (0 for none): ", 0)
except ValueError:
    print("Enter valid positive numbers")
else:
    pending_loss = {lost} if 1 <= lost <= total else set()
    base = 1
    print("Go-Back-N Protocol")
    while base <= total:
        end = min(base + window - 1, total)
        print(f"\nWindow: frames {base} to {end}")
        failed_at = None
        for frame in range(base, end + 1):
            print("Sender   - sending frame", frame)
            if failed_at is not None:
                print("Receiver - discarded out-of-order frame", frame)
            elif frame in pending_loss:
                pending_loss.remove(frame)
                failed_at = frame
                print("Network  - frame", frame, "lost")
            else:
                print("Receiver - got frame", frame, "and sent ACK", frame)
        if failed_at is None:
            base = end + 1
        else:
            print("Sender   - timeout for frame", failed_at, "- going back and resending from it")
            base = failed_at
    print("\nAll frames delivered")

import ipaddress

ip = input("Enter IP address: ").strip()
prefix = input("Enter prefix (e.g. 24): ").strip()

try:
    net = ipaddress.ip_network(f"{ip}/{int(prefix)}", strict=False)
except ValueError:
    print("Invalid IP address or prefix")
else:
    print("Network address:", net.network_address)
    print("Broadcast address:", net.broadcast_address)
    print("Subnet mask:", net.netmask)
    print("Total addresses:", net.num_addresses)
    if net.prefixlen <= 30:
        print("First usable:", net.network_address + 1)
        print("Last usable:", net.broadcast_address - 1)
        print("Usable hosts:", net.num_addresses - 2)
    elif net.prefixlen == 31:
        print("Point-to-point subnet: 2 addresses")
    else:
        print("Single host address:", net.network_address)

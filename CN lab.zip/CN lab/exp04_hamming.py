def encode(data):
    d1, d2, d3, d4 = map(int, data)
    p1 = d1 ^ d2 ^ d4
    p2 = d1 ^ d3 ^ d4
    p4 = d2 ^ d3 ^ d4
    return [p1, p2, d1, p4, d2, d3, d4]


def correct(code):
    b = [0] + code
    s1 = b[1] ^ b[3] ^ b[5] ^ b[7]
    s2 = b[2] ^ b[3] ^ b[6] ^ b[7]
    s4 = b[4] ^ b[5] ^ b[6] ^ b[7]
    position = s1 + 2 * s2 + 4 * s4
    if position:
        b[position] ^= 1
    return position, b[1:]


data = input("Enter 4 data bits: ").strip()
if len(data) != 4 or set(data) - {"0", "1"}:
    print("Enter exactly 4 binary bits")
else:
    sent = encode(data)
    print("Sender   - Hamming code:", "".join(map(str, sent)))

    received = input("Receiver - enter 7 received bits (press Enter to use the sent code): ").strip()
    received = list(map(int, received)) if received else sent
    if len(received) != 7 or any(b not in (0, 1) for b in received):
        print("Enter exactly 7 binary bits")
    else:
        position, fixed = correct(received)
        if position:
            print("Receiver - error found at position:", position)
        else:
            print("Receiver - no error detected")
        print("Receiver - corrected code:", "".join(map(str, fixed)))
        print("Receiver - data bits:", "".join(str(fixed[i]) for i in (2, 4, 5, 6)))

def read_int(prompt, minimum=1):
    value = int(input(prompt))
    if value < minimum:
        raise ValueError
    return value


try:
    total = read_int("Enter total number of frames: ")
    window = read_int("Enter window size: ")
    lost = read_int("Enter frame number to lose once (0 for none): ", 0)
except ValueError:
    print("Enter valid positive numbers")
else:
    pending_loss = {lost} if 1 <= lost <= total else set()
    base = 1
    print("Selective Repeat Protocol")
    while base <= total:
        end = min(base + window - 1, total)
        print(f"\nWindow: frames {base} to {end}")
        missing = []
        for frame in range(base, end + 1):
            print("Sender   - sending frame", frame)
            if frame in pending_loss:
                pending_loss.remove(frame)
                missing.append(frame)
                print("Network  - frame", frame, "lost")
            else:
                print("Receiver - got frame", frame, "and sent ACK", frame)
        for frame in missing:
            print("Sender   - timeout, resending only frame", frame)
            print("Receiver - got frame", frame, "and sent ACK", frame)
        print("Receiver - delivered frames", base, "to", end, "in order")
        base = end + 1
    print("\nAll frames delivered")

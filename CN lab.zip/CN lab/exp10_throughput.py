try:
    data_mb = float(input("Enter data delivered in MB: "))
    time_sec = float(input("Enter time in seconds: "))
except ValueError:
    print("Enter valid numbers")
else:
    if data_mb >= 0 and time_sec > 0:
        print("Throughput:", data_mb * 8 / time_sec, "Mbps")
    else:
        print("Enter valid values")

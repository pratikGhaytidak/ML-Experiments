import socket
import threading

HOST = "127.0.0.1"
PORT = 5000
ready = threading.Event()


def server():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((HOST, PORT))
        s.listen(1)
        print("Server waiting...")
        ready.set()
        conn, addr = s.accept()
        with conn:
            print("Client connected:", addr)
            message = conn.recv(1024).decode()
            print("Client says:", message)
            conn.sendall(b"Hello from server")


def client():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as c:
        c.connect((HOST, PORT))
        c.sendall(b"Hello from client")
        reply = c.recv(1024).decode()
        print("Server says:", reply)


listener = threading.Thread(target=server)
listener.start()
ready.wait()
client()
listener.join()

Computer Networks Lab Codes

Run any Python file with: python filename.py

Sender and receiver sides are combined in a single file for:
exp03 (bit and character stuffing), exp04 (CRC, Hamming),
exp05 (Go-Back-N, Selective Repeat), exp08 (TCP, UDP).

exp08_tcp.py and exp08_udp.py start the server in a background thread and
run the client in the same program, so one terminal is enough.

Experiment 1 and 2 files contain Windows network commands.
Experiment 9 file contains Wireshark display filters.

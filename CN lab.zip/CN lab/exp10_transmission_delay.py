try:
    size_bytes = float(input("Enter packet size in bytes: "))
    rate_mbps = float(input("Enter link speed in Mbps: "))
except ValueError:
    print("Enter valid numbers")
else:
    if size_bytes > 0 and rate_mbps > 0:
        print("Transmission delay:", size_bytes * 8 / (rate_mbps * 1_000_000), "seconds")
    else:
        print("Enter valid values")

def xor_divide(bits, generator):
    bits = bits[:]
    for i in range(len(bits) - len(generator) + 1):
        if bits[i] == 1:
            for j, g in enumerate(generator):
                bits[i + j] ^= g
    return bits[-(len(generator) - 1):]


def to_bits(text):
    return [int(b) for b in text]


data = input("Enter data bits: ").strip()
gen = input("Enter generator bits: ").strip()
valid = data and gen and not set(data + gen) - {"0", "1"}
if not valid or len(gen) < 2 or gen[0] != "1":
    print("Invalid binary input")
else:
    generator = to_bits(gen)
    padded = to_bits(data) + [0] * (len(gen) - 1)
    remainder = "".join(map(str, xor_divide(padded, generator)))
    codeword = data + remainder
    print("Sender   - CRC remainder:", remainder)
    print("Sender   - codeword sent:", codeword)

    received = input("Receiver - enter received codeword (press Enter to use the sent one): ").strip() or codeword
    if len(received) < len(gen) or set(received) - {"0", "1"}:
        print("Invalid received codeword")
    elif any(xor_divide(to_bits(received), generator)):
        print("Receiver - error detected in received data")
    else:
        print("Receiver - no error detected")

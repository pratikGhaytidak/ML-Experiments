FLAG = "F"
ESC = "E"


def stuff(data):
    result = ""
    for ch in data:
        if ch in (FLAG, ESC):
            result += ESC
        result += ch
    return result


def destuff(data):
    result = ""
    i = 0
    while i < len(data):
        if data[i] == ESC and i + 1 < len(data):
            i += 1
        result += data[i]
        i += 1
    return result


data = input("Enter data: ")
sent = stuff(data)
print("Sender   - stuffed data:", sent)
received = destuff(sent)
print("Receiver - destuffed data:", received)
print("Data received correctly" if received == data else "Data mismatch")

def stuff(data):
    result = ""
    ones = 0
    for bit in data:
        result += bit
        ones = ones + 1 if bit == "1" else 0
        if ones == 5:
            result += "0"
            ones = 0
    return result


def destuff(data):
    result = ""
    ones = 0
    skip = False
    for bit in data:
        if skip:
            skip = False
            continue
        result += bit
        ones = ones + 1 if bit == "1" else 0
        if ones == 5:
            skip = True
            ones = 0
    return result


data = input("Enter binary data: ").strip()
if not data or set(data) - {"0", "1"}:
    print("Enter valid binary data")
else:
    sent = stuff(data)
    print("Sender   - stuffed data:", sent)
    received = destuff(sent)
    print("Receiver - destuffed data:", received)
    print("Data received correctly" if received == data else "Data mismatch")

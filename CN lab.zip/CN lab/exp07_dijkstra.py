import heapq

graph = {
    "A": {"B": 2, "C": 5},
    "B": {"A": 2, "C": 1, "D": 4},
    "C": {"A": 5, "B": 1, "D": 2},
    "D": {"B": 4, "C": 2},
}


def shortest_path(start, end):
    dist = {node: float("inf") for node in graph}
    parent = {node: None for node in graph}
    dist[start] = 0
    queue = [(0, start)]
    while queue:
        cost, node = heapq.heappop(queue)
        if cost > dist[node]:
            continue
        if node == end:
            break
        for neighbour, weight in graph[node].items():
            new_cost = cost + weight
            if new_cost < dist[neighbour]:
                dist[neighbour] = new_cost
                parent[neighbour] = node
                heapq.heappush(queue, (new_cost, neighbour))
    if dist[end] == float("inf"):
        return None, None
    path = []
    node = end
    while node is not None:
        path.append(node)
        node = parent[node]
    return path[::-1], dist[end]


start = input("Enter source node: ").strip().upper()
end = input("Enter destination node: ").strip().upper()
if start not in graph or end not in graph:
    print("Invalid node")
else:
    path, cost = shortest_path(start, end)
    if path is None:
        print("No path found")
    else:
        print("Shortest path:", " -> ".join(path))
        print("Total cost:", cost)
